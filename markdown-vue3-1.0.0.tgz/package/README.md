[# markdown-vue3

#### 介绍

**markdown-vue3** 是一个轻量、高效的 Markdown 渲染组件，基于 Vue 3 开发。  
支持常见 Markdown 语法、代码高亮、自定义样式，适用于博客系统、文档站点、内容管理系统等场景。

#### 软件架构

- 基于 **Vue 3** 开发，使用 Composition API
- 使用 **marked** 作为 Markdown 解析器
- 使用 **highlight.js** 或 **Prism.js** 实现代码语法高亮
- 支持按需加载，支持自定义渲染规则

#### 安装教程

1. 安装依赖：
   ``` bash
   npm install markdown-vue3
   pnpm add markdown-vue3
   ``` bash

2. 若需要代码高亮，请额外安装高亮库：
   ```bash
   npm install highlight.js
   ```

#### 使用说明

1. **全局注册组件**（在 \`main.js\` 中）：
   ``` javascript
   import { createApp } from 'vue'
   import App from './App.vue'
   import MarkdownVue3 from 'markdown-vue3'

   const app = createApp(App)
   app.use(MarkdownVue3)
   app.mount('#app')
   ``` bash

2. **在组件中使用**：
   ```vue
   <template>
     <markdown-vue3 :content="markdownContent" />
   </template>

   <script setup>
   import { ref } from 'vue';

   const markdownContent = ref('# 标题\\n\\n这是一段 **Markdown** 内容。')
   </script>
   ```

3. **自定义高亮样式**：
   引入高亮库的样式文件（以 highlight.js 为例）：
   ```javascript
   import 'highlight.js/styles/github.css'
   ```

#### 参与贡献

1. Fork 本仓库
2. 新建 Feat_xxx 分支
3. 提交代码
4. 新建 Pull Request

#### 特技

1. 使用 Readme_XXX.md 来支持不同的语言，例如 Readme_en.md, Readme_zh.md
2. Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3. 你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4. [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5. Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6. Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)]()